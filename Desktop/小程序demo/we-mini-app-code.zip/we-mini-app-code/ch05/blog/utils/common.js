var baseUrl = 'http://localhost/weixinbook/cnblogs/';
//var baseUrl = 'http://www.weixinbook.net/cnblogs/';
module.exports = {
  baseUrl: baseUrl
}