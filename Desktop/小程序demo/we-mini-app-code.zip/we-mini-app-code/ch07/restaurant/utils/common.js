var baseUrl = 'http://localhost/restaurant/';
module.exports = {
  baseUrl: baseUrl
}
